// File: android/app/src/main/java/com/emerald/pdftoolkit/MainActivity.kt
package com.emerald.pdftoolkit

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        configureOfflineWebViewCache()
        registerHardwareBackHandler()
    }

    /**
     * Configures the Capacitor WebView for high-performance client-side PDF canvas
     * processing and offline-first Service Worker / DOM storage caching.
     */
    private fun configureOfflineWebViewCache() {
        val webView: WebView = bridge?.webView ?: return
        val settings: WebSettings = webView.settings

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.mediaPlaybackRequiresUserGesture = false
    }

    /**
     * Android 14+ (API 34) predictive back gesture & hardware back-button support.
     * Navigates WebView history or delegates workspace reset before exiting the app.
     */
    private fun registerHardwareBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val webView = bridge?.webView
                if (webView != null && webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) {
            bridge?.webView?.clearCache(false)
        }
    }
}
