// File: public/js/app.js
import { ClientPdfEngine } from './pdf-engine.js';
import { ClientUtilityEngine } from './utility-engine.js';
import { ONECLICK_TOOLS } from './tools-catalog.js';

class OneClickApp {
  constructor() {
    this.pdfEngine = new ClientPdfEngine();
    this.utilEngine = new ClientUtilityEngine();
    this.activeTool = 'merge';
    this.activeCategory = 'all';
    this.searchQuery = '';

    /** @type {Array<{id: string, type: 'pdf'|'image', fileName: string, fileSize: number, buffer?: ArrayBuffer, file?: File, pageIndex?: number, rotation: number, selected: boolean, objectUrl?: string}>} */
    this.items = [];
    this.dragSrcIndex = null;

    this.lastOutputData = null;
    this.lastOutputName = 'oneclick-output.pdf';
    this.lastOutputMime = 'application/pdf';
    this.deferredInstallPrompt = null;

    // Typing speed state
    this.typingStartTime = null;
    this.typingInterval = null;
    this.stopwatchInterval = null;
    this.stopwatchElapsedMs = 0;

    this._initDomRefs();
    this._initTheme();
    this._renderToolsDirectory();
    this._bindEvents();
    this._registerServiceWorker();
    this._setupMobileBackNavigation();
    this._renderToolConfigSidebar();
  }

  _initDomRefs() {
    this.toolsGrid = document.getElementById('toolsGrid');
    this.toolSearchInput = document.getElementById('toolSearchInput');
    this.categoryTabs = document.querySelectorAll('.cat-tab');
    this.navLinks = document.querySelectorAll('.nav-link');
    this.directorySectionHeading = document.getElementById('directorySectionHeading');
    this.toolCountBadge = document.getElementById('toolCountBadge');

    this.dropzone = document.getElementById('dropzone');
    this.fileInput = document.getElementById('fileInput');
    this.pagesGrid = document.getElementById('pagesGrid');
    this.statsPill = document.getElementById('statsPill');
    this.rotateAllBtn = document.getElementById('rotateAllBtn');
    this.reverseAllBtn = document.getElementById('reverseAllBtn');
    this.clearAllBtn = document.getElementById('clearAllBtn');
    this.demoSampleBtn = document.getElementById('demoSampleBtn');

    this.configContainer = document.getElementById('toolConfigContainer');
    this.sidebarIcon = document.getElementById('sidebarIcon');
    this.sidebarTitleText = document.getElementById('sidebarTitleText');
    this.sidebarSubtitleText = document.getElementById('sidebarSubtitleText');
    this.processBtn = document.getElementById('processBtn');

    this.progressBox = document.getElementById('progressBox');
    this.progressFill = document.getElementById('progressFill');
    this.progressStatus = document.getElementById('progressStatus');
    this.progressPercent = document.getElementById('progressPercent');

    this.resultCard = document.getElementById('resultCard');
    this.resultMetaText = document.getElementById('resultMetaText');
    this.resultExtraContainer = document.getElementById('resultExtraContainer');
    this.downloadResultBtn = document.getElementById('downloadResultBtn');

    this.themeToggleBtn = document.getElementById('themeToggleBtn');
    this.installPwaBtn = document.getElementById('installPwaBtn');
  }

  _initTheme() {
    const saved = localStorage.getItem('oneclick_theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const theme = saved || (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
  }

  _setCategory(cat) {
    this.activeCategory = cat;
    this.categoryTabs.forEach((t) => t.classList.toggle('active', t.dataset.cat === cat));
    this.navLinks.forEach((n) => n.classList.toggle('active', n.dataset.nav === cat));

    const HEADINGS = {
      all: '🔥 All 100 Free Tools Directory',
      pdf: '📑 PDF & Document Tools (40)',
      image: '🖼️ Image & Photo Studio Tools (25)',
      calc: '🎂 Date, Age, Typing & Calculator Tools (20)',
      text: '🔤 Text, QR & Developer Utilities (20)'
    };
    if (this.directorySectionHeading) {
      this.directorySectionHeading.textContent = HEADINGS[cat] || HEADINGS.all;
    }
    this._renderToolsDirectory();
  }

  _renderToolsDirectory() {
    this.toolsGrid.innerHTML = '';
    const q = this.searchQuery.toLowerCase().trim();

    const filtered = ONECLICK_TOOLS.filter((t) => {
      const matchCat = this.activeCategory === 'all' || t.cat === this.activeCategory;
      const matchSearch =
        !q ||
        t.title.toLowerCase().includes(q) ||
        t.desc.toLowerCase().includes(q) ||
        t.cat.toLowerCase().includes(q) ||
        t.id.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });

    if (this.toolCountBadge) {
      this.toolCountBadge.textContent = `Showing ${filtered.length} Tools`;
    }

    if (filtered.length === 0) {
      this.toolsGrid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 2rem; color: var(--text-muted);">
          No tools matched "<strong>${this.searchQuery}</strong>". Try clearing the search filter.
        </div>
      `;
      return;
    }

    const CAT_LABELS = {
      pdf: 'PDF & Document',
      image: 'Image & Photo',
      calc: 'Calculator & Date',
      text: 'Text & Dev Utility'
    };

    for (const tool of filtered) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `tool-card ${this.activeTool === tool.id ? 'active' : ''}`;
      btn.dataset.tool = tool.id;
      btn.innerHTML = `
        <div class="tool-card-icon">${tool.icon}</div>
        <div class="tool-card-body">
          <div class="tool-card-title">${tool.title}</div>
          <div class="tool-card-desc">${tool.desc}</div>
          <div class="tool-badge-cat">${CAT_LABELS[tool.cat] || tool.cat}</div>
        </div>
      `;
      btn.addEventListener('click', () => {
        this.switchTool(tool.id);
        document.getElementById('studioWorkspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
      this.toolsGrid.appendChild(btn);
    }
  }

  _bindEvents() {
    this.themeToggleBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('oneclick_theme', next);
    });

    this.toolSearchInput.addEventListener('input', (e) => {
      this.searchQuery = e.target.value;
      this._renderToolsDirectory();
    });

    this.categoryTabs.forEach((tab) => {
      tab.addEventListener('click', () => this._setCategory(tab.dataset.cat));
    });

    this.navLinks.forEach((nav) => {
      nav.addEventListener('click', () => this._setCategory(nav.dataset.nav));
    });

    this.dropzone.addEventListener('click', () => this.fileInput.click());
    this.dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      this.dropzone.classList.add('dragover');
    });
    this.dropzone.addEventListener('dragleave', () => {
      this.dropzone.classList.remove('dragover');
    });
    this.dropzone.addEventListener('drop', async (e) => {
      e.preventDefault();
      this.dropzone.classList.remove('dragover');
      if (e.dataTransfer?.files?.length) {
        await this.handleFiles(Array.from(e.dataTransfer.files));
      }
    });

    this.fileInput.addEventListener('change', async (e) => {
      if (e.target.files?.length) {
        await this.handleFiles(Array.from(e.target.files));
        this.fileInput.value = '';
      }
    });

    this.rotateAllBtn.addEventListener('click', () => {
      if (!this.items.length) return;
      this.items.forEach((item) => {
        item.rotation = (item.rotation + 90) % 360;
      });
      this.renderThumbnails();
    });

    this.reverseAllBtn.addEventListener('click', () => {
      if (!this.items.length) return;
      this.items.reverse();
      this.renderThumbnails();
    });

    this.clearAllBtn.addEventListener('click', () => this.clearWorkspace());
    this.demoSampleBtn.addEventListener('click', () => this.loadSampleDocument());
    this.processBtn.addEventListener('click', () => this.executeCurrentTool());

    this.downloadResultBtn.addEventListener('click', () => {
      if (this.lastOutputData) {
        this.pdfEngine.memory.triggerDownload(this.lastOutputData, this.lastOutputName, this.lastOutputMime);
      }
    });

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      this.deferredInstallPrompt = e;
      this.installPwaBtn.style.display = 'inline-flex';
    });

    this.installPwaBtn.addEventListener('click', async () => {
      if (!this.deferredInstallPrompt) return;
      this.deferredInstallPrompt.prompt();
      await this.deferredInstallPrompt.userChoice;
      this.deferredInstallPrompt = null;
      this.installPwaBtn.style.display = 'none';
    });

    window.addEventListener('beforeunload', () => {
      this.pdfEngine.memory.revokeAll();
    });
  }

  _registerServiceWorker() {
    if (
      'serviceWorker' in navigator &&
      (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')
    ) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }

  _setupMobileBackNavigation() {
    window.addEventListener('ionBackButton', (ev) => {
      if (this.items.length > 0) {
        ev.detail.register(10, () => {
          this.clearWorkspace();
        });
      }
    });
  }

  switchTool(toolId) {
    this.activeTool = toolId;
    this._renderToolsDirectory();
    this.resultCard.classList.remove('visible');
    this.resultExtraContainer.innerHTML = '';
    this._renderToolConfigSidebar();
  }

  async handleFiles(fileList) {
    this.resultCard.classList.remove('visible');
    this._setProgress(15, 'Loading local files into browser RAM...');

    for (const file of fileList) {
      const isImage = file.type.startsWith('image/');
      const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');

      if (isImage) {
        const objUrl = this.pdfEngine.memory.createManagedUrl(file, file.type);
        this.items.push({
          id: crypto.randomUUID(),
          type: 'image',
          fileName: file.name,
          fileSize: file.size,
          file,
          rotation: 0,
          selected: true,
          objectUrl: objUrl
        });
      } else if (isPdf) {
        const buffer = await file.arrayBuffer();
        const pageCount = await this.pdfEngine.getPageCount(buffer);
        for (let p = 0; p < pageCount; p++) {
          this.items.push({
            id: crypto.randomUUID(),
            type: 'pdf',
            fileName: file.name,
            fileSize: file.size,
            buffer,
            pageIndex: p,
            rotation: 0,
            selected: true
          });
        }
      }
    }

    this._hideProgress();
    await this.renderThumbnails();
  }

  async loadSampleDocument() {
    this._setProgress(25, 'Generating 3-page sample PDF in memory...');
    const { PDFDocument, StandardFonts, rgb } = window.PDFLib;
    const sampleDoc = await PDFDocument.create();
    const fontBold = await sampleDoc.embedFont(StandardFonts.HelveticaBold);
    const fontReg = await sampleDoc.embedFont(StandardFonts.Helvetica);

    const samplePages = [
      { title: 'Executive Summary — Q4 Global Report', badge: 'Page 1 • OneClick Suite' },
      { title: 'Architecture & Security Audit (Zero-Trust)', badge: 'Page 2 • 100% Client-Side' },
      { title: 'Appendix A — Revenue & Operations', badge: 'Page 3 • Confidential' }
    ];

    samplePages.forEach((info, idx) => {
      const page = sampleDoc.addPage([595.28, 841.89]);
      page.drawRectangle({ x: 0, y: 740, width: 595.28, height: 101.89, color: rgb(0.023, 0.306, 0.231) });
      page.drawText('ONECLICK — 100+ FREE TOOLS SUITE', { x: 42, y: 785, size: 17, font: fontBold, color: rgb(1, 1, 1) });
      page.drawText(info.badge, { x: 42, y: 760, size: 11, font: fontReg, color: rgb(0.96, 0.62, 0.04) });

      page.drawText(info.title, { x: 42, y: 660, size: 16, font: fontBold, color: rgb(0.06, 0.09, 0.16) });
      page.drawText(
        `This synthetic document was generated 100% inside your browser using pdf-lib.\nTest any of the 100+ OneClick tools: Merge, Split, PDF to JPG/PNG, Extract Text,\nSign PDF, Grayscale, Crop, Page Numbers, Image Studio, Age Calc, or Typing Test.`,
        { x: 42, y: 615, size: 11.5, font: fontReg, color: rgb(0.28, 0.33, 0.41), lineHeight: 18 }
      );

      page.drawRectangle({
        x: 42,
        y: 260,
        width: 511,
        height: 290,
        borderColor: rgb(0.85, 0.46, 0.02),
        borderWidth: 1.5,
        color: rgb(0.98, 0.99, 0.98)
      });
      page.drawText(`OneClick Interactive Vector Block — Page #${idx + 1}`, {
        x: 145,
        y: 400,
        size: 14,
        font: fontBold,
        color: rgb(0.023, 0.306, 0.231)
      });
    });

    const pdfBytes = await sampleDoc.save();
    const sampleFile = new File([pdfBytes], 'OneClick-Sample-Report.pdf', { type: 'application/pdf' });
    await this.handleFiles([sampleFile]);
  }

  clearWorkspace() {
    this.pdfEngine.memory.revokeAll();
    this.items = [];
    this.lastOutputData = null;
    this.resultCard.classList.remove('visible');
    this.resultExtraContainer.innerHTML = '';
    this.renderThumbnails();
  }

  async renderThumbnails() {
    this.pagesGrid.innerHTML = '';
    this.statsPill.textContent = `${this.items.length} ${this.items.length === 1 ? 'Item' : 'Items'} Loaded`;

    if (this.items.length === 0) {
      this.pagesGrid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 2.25rem 1rem; color: var(--text-muted);">
          <p>Drop PDF or Image files above, click <strong>"✨ Load Sample PDF"</strong> in the header, or pick any tool from the <strong>100+ Free Tools</strong> directory below.</p>
        </div>
      `;
      return;
    }

    for (let index = 0; index < this.items.length; index++) {
      const item = this.items[index];
      const card = document.createElement('div');
      card.className = `page-thumb ${item.selected ? 'selected' : ''}`;
      card.draggable = true;
      card.dataset.index = String(index);

      const canvasWrap = document.createElement('div');
      canvasWrap.className = 'thumb-canvas-wrap';

      if (item.type === 'image') {
        const img = document.createElement('img');
        img.src = item.objectUrl;
        img.alt = item.fileName;
        img.style.transform = `rotate(${item.rotation}deg)`;
        canvasWrap.appendChild(img);
      } else {
        const canvas = document.createElement('canvas');
        canvas.style.transform = `rotate(${item.rotation}deg)`;
        canvasWrap.appendChild(canvas);
        this.pdfEngine.renderPageThumbnail(item.buffer, item.pageIndex + 1, canvas, 0.32).catch(() => {});
      }

      const footer = document.createElement('div');
      footer.className = 'thumb-footer';
      footer.innerHTML = `
        <span title="${item.fileName}">#${index + 1} ${item.type === 'pdf' ? `(P.${item.pageIndex + 1})` : '(IMG)'}</span>
        <div class="thumb-actions">
          <button type="button" class="thumb-btn" data-action="dup" title="Duplicate">⧉</button>
          <button type="button" class="thumb-btn" data-action="rotate" title="Rotate 90°">↻</button>
          <button type="button" class="thumb-btn" data-action="delete" title="Remove">✕</button>
        </div>
      `;

      footer.querySelector('[data-action="dup"]').addEventListener('click', (e) => {
        e.stopPropagation();
        const clone = { ...item, id: crypto.randomUUID() };
        this.items.splice(index + 1, 0, clone);
        this.renderThumbnails();
      });

      footer.querySelector('[data-action="rotate"]').addEventListener('click', (e) => {
        e.stopPropagation();
        item.rotation = (item.rotation + 90) % 360;
        this.renderThumbnails();
      });

      footer.querySelector('[data-action="delete"]').addEventListener('click', (e) => {
        e.stopPropagation();
        if (item.objectUrl) this.pdfEngine.memory.revokeUrl(item.objectUrl);
        this.items.splice(index, 1);
        this.renderThumbnails();
      });

      card.addEventListener('dragstart', (e) => {
        this.dragSrcIndex = index;
        card.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
      });

      card.addEventListener('dragend', () => card.classList.remove('dragging'));
      card.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
      });

      card.addEventListener('drop', (e) => {
        e.preventDefault();
        const targetIndex = index;
        if (this.dragSrcIndex !== null && this.dragSrcIndex !== targetIndex) {
          const [moved] = this.items.splice(this.dragSrcIndex, 1);
          this.items.splice(targetIndex, 0, moved);
          this.dragSrcIndex = null;
          this.renderThumbnails();
        }
      });

      card.appendChild(canvasWrap);
      card.appendChild(footer);
      this.pagesGrid.appendChild(card);
    }
  }

  _renderToolConfigSidebar() {
    const tool = ONECLICK_TOOLS.find((t) => t.id === this.activeTool) || ONECLICK_TOOLS[0];
    this.sidebarIcon.textContent = tool.icon;
    this.sidebarTitleText.textContent = tool.title;
    this.sidebarSubtitleText.textContent = tool.desc;
    this.processBtn.textContent = `⚡ Run ${tool.title}`;

    const h = tool.handler;

    // 1. PDF Merge / Reorder / Rotate / Reverse
    if (h === 'pdf_merge' || h === 'pdf_reverse') {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-${tool.id}.pdf" />
        </div>
        <p style="font-size:0.79rem;color:var(--text-secondary);line-height:1.45;">
          Drag thumbnails on the left to reorder, duplicate (<strong>⧉</strong>), or rotate (<strong>↻</strong>) pages before saving.
        </p>
      `;
    }
    // 2. PDF Split / Extract / Remove
    else if (h === 'pdf_split' || h === 'pdf_remove') {
      const isRemove = h === 'pdf_remove';
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="splitRangeInput">
            <span>${isRemove ? 'Page Ranges to Remove' : 'Page Ranges to Extract'}</span>
            <span style="color:var(--gold-600)">e.g. 1-2, 4</span>
          </label>
          <input id="splitRangeInput" class="form-input" type="text" value="1" />
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-${tool.id}.pdf" />
        </div>
      `;
    }
    // 3. PDF Compress / Flatten / Repair / Rasterize
    else if (h === 'pdf_compress') {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="compressPresetSelect">Optimization Profile</label>
          <select id="compressPresetSelect" class="form-select">
            <option value="extreme">Extreme Compression (Smallest Size, 50% Quality)</option>
            <option value="recommended" selected>Recommended Balance (68% Quality, 125% DPI)</option>
            <option value="high">High Fidelity Flatten (85% Quality, 150% DPI)</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-${tool.id}.pdf" />
        </div>
      `;
    }
    // 4. PDF Grayscale / Invert / Scanner Contrast
    else if (h === 'pdf_grayscale' || h === 'pdf_invert' || h === 'pdf_contrast') {
      const def = h === 'pdf_invert' ? 'invert' : h === 'pdf_contrast' ? 'contrast' : 'grayscale';
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="colorFilterSelect">Color Filter Mode</label>
          <select id="colorFilterSelect" class="form-select">
            <option value="grayscale" ${def === 'grayscale' ? 'selected' : ''}>Grayscale (Ink-Saving B&amp;W)</option>
            <option value="contrast" ${def === 'contrast' ? 'selected' : ''}>High-Contrast Scanner Clean</option>
            <option value="invert" ${def === 'invert' ? 'selected' : ''}>Invert Colors (Dark Mode PDF)</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-${tool.id}.pdf" />
        </div>
      `;
    }
    // 5. Sign PDF
    else if (h === 'pdf_sign') {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label">
            <span>Draw Your Signature</span>
            <button id="clearSigBtn" type="button" style="background:none;border:none;color:var(--gold-600);cursor:pointer;font-weight:700;font-size:0.75rem;">Clear Pad</button>
          </label>
          <div class="signature-pad-wrap">
            <canvas id="signatureCanvas" class="signature-canvas" width="320" height="120"></canvas>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label" for="sigSignerInput">Signer Name Stamp</label>
          <input id="sigSignerInput" class="form-input" type="text" value="Verified Signatory" />
        </div>
        <div class="form-group">
          <label class="form-label" for="sigPosSelect">Placement</label>
          <select id="sigPosSelect" class="form-select">
            <option value="bottom-right" selected>Bottom Right Corner</option>
            <option value="bottom-left">Bottom Left Corner</option>
            <option value="bottom-center">Bottom Center</option>
            <option value="center">Page Center</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="sigTargetSelect">Target Pages</label>
          <select id="sigTargetSelect" class="form-select">
            <option value="last" selected>Last Page Only</option>
            <option value="first">First Page Only</option>
            <option value="all">Every Page</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-signed.pdf" />
        </div>
      `;
      this._initSignaturePad();
    }
    // 6. Watermark PDF
    else if (h === 'pdf_watermark') {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="wmTextInput">Watermark Text</label>
          <input id="wmTextInput" class="form-input" type="text" value="CONFIDENTIAL • ONECLICK" />
        </div>
        <div class="form-group">
          <label class="form-label" for="wmPlacementSelect">Placement</label>
          <select id="wmPlacementSelect" class="form-select">
            <option value="diagonal" selected>Diagonal Center Stamp</option>
            <option value="header">Top Header Stamp</option>
            <option value="footer">Bottom Footer Stamp</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="wmOpacityInput">Opacity (0.05 – 0.95)</label>
          <input id="wmOpacityInput" class="form-input" type="number" step="0.05" min="0.05" max="0.95" value="0.28" />
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-watermarked.pdf" />
        </div>
      `;
    }
    // 7. Page Numbers & Header/Footer
    else if (h === 'pdf_pagenums') {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="pnFormatInput">Page Number Format</label>
          <input id="pnFormatInput" class="form-input" type="text" value="Page {n} of {total}" />
        </div>
        <div class="form-group">
          <label class="form-label" for="pnHeaderInput">Top Running Header</label>
          <input id="pnHeaderInput" class="form-input" type="text" value="${tool.id === 'headerfooter' ? 'OneClick Official Document' : ''}" placeholder="Optional header text" />
        </div>
        <div class="form-group">
          <label class="form-label" for="pnPosSelect">Position</label>
          <select id="pnPosSelect" class="form-select">
            <option value="bottom-center" selected>Bottom Center</option>
            <option value="bottom-right">Bottom Right</option>
            <option value="bottom-left">Bottom Left</option>
            <option value="top-right">Top Right</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-numbered.pdf" />
        </div>
      `;
    }
    // 8. Crop or Resize PDF
    else if (h === 'pdf_crop' || h === 'pdf_resize') {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="cropModeSelect">Geometry Mode</label>
          <select id="cropModeSelect" class="form-select">
            <option value="crop" ${h === 'pdf_crop' ? 'selected' : ''}>Crop / Trim Margins</option>
            <option value="resize" ${h === 'pdf_resize' ? 'selected' : ''}>Resize Page to Standard Size</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="cropSizeSelect">Target Page Size</label>
          <select id="cropSizeSelect" class="form-select">
            <option value="A4" selected>A4 (595 × 842 pt)</option>
            <option value="LETTER">US Letter (612 × 792 pt)</option>
            <option value="LEGAL">US Legal (612 × 1008 pt)</option>
            <option value="A3">A3 Poster (842 × 1191 pt)</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="cropMarginInput">Margin / Padding (pt)</label>
          <input id="cropMarginInput" class="form-input" type="number" min="0" max="180" value="28" />
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-${tool.id}.pdf" />
        </div>
      `;
    }
    // 9. Insert Blank Pages / 2-Up / Booklet
    else if (h === 'pdf_blank' || h === 'pdf_twoup') {
      this.configContainer.innerHTML = `
        ${
          h === 'pdf_blank'
            ? `<div class="form-group">
                <label class="form-label" for="blankPosSelect">Insert Position</label>
                <select id="blankPosSelect" class="form-select">
                  <option value="end" selected>End of Document</option>
                  <option value="start">Beginning (Cover Page)</option>
                  <option value="between">Between Every Existing Page</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label" for="blankCountInput">Blank Page Count</label>
                <input id="blankCountInput" class="form-input" type="number" min="1" max="20" value="1" />
              </div>`
            : `<p style="font-size:0.78rem;color:var(--text-secondary);">Places 2 consecutive pages side-by-side onto each A4 Landscape sheet.</p>`
        }
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-${tool.id}.pdf" />
        </div>
      `;
    }
    // 10. Redact / Metadata Scrub / Metadata Edit
    else if (h === 'pdf_redact' || h === 'pdf_scrub_meta' || h === 'pdf_edit_meta') {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="metaTitleInput">${h === 'pdf_redact' ? 'Redaction Stamp Label' : 'Document Title'}</label>
          <input id="metaTitleInput" class="form-input" type="text" value="${h === 'pdf_redact' ? 'CONFIDENTIAL REDACTED' : 'OneClick Document'}" />
        </div>
        <div class="form-group">
          <label class="form-label" for="metaAuthorInput">Document Author</label>
          <input id="metaAuthorInput" class="form-input" type="text" value="OneClick Security Suite" />
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-${tool.id}.pdf" />
        </div>
      `;
    }
    // 11. PDF to Images (JPG / PNG / WebP) or Extract Text
    else if (h === 'pdf_to_jpg' || h === 'pdf_to_png' || h === 'pdf_to_webp' || h === 'pdf_extract_text') {
      this.configContainer.innerHTML = `
        ${
          h !== 'pdf_extract_text'
            ? `<div class="form-group">
                <label class="form-label" for="exportDpiSelect">Render Resolution (DPI)</label>
                <select id="exportDpiSelect" class="form-select">
                  <option value="1.5">Standard (150 DPI)</option>
                  <option value="2.0" selected>High Definition (200 DPI)</option>
                  <option value="3.0">Ultra Print Quality (300 DPI)</option>
                </select>
              </div>`
            : `<div class="form-group">
                <label class="form-label" for="outputNameInput">Output Filename</label>
                <input id="outputNameInput" class="form-input" type="text" value="oneclick-extracted.txt" />
              </div>`
        }
      `;
    }
    // 12. Write Text / Notes / Invoice to PDF
    else if (h === 'text_to_pdf' || h === 'invoice_to_pdf') {
      const isInv = h === 'invoice_to_pdf';
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="txtTitleInput">${isInv ? 'Invoice Header / Company' : 'Document Title'}</label>
          <input id="txtTitleInput" class="form-input" type="text" value="${isInv ? 'INVOICE #INV-2026-001 • OneClick Studio' : 'OneClick Executive Document'}" />
        </div>
        <div class="form-group">
          <label class="form-label" for="txtBodyInput">${isInv ? 'Invoice Line Items & Notes' : 'Document Body Content'}</label>
          <textarea id="txtBodyInput" class="form-textarea">${
            isInv
              ? 'Bill To: Global Client Corp\nDate: 2026-11-09\n----------------------------------------\n1. Full-Stack Web & Mobile Development   $1,200.00\n2. UI/UX Design & Brand Identity         $450.00\n3. SEO & Cloud Deployment Setup          $250.00\n----------------------------------------\nTOTAL DUE:                               $1,900.00\n\nThank you for your business!'
              : 'Write or paste your content here. OneClick generates a multi-page A4 PDF 100% locally inside your browser.'
          }</textarea>
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-${tool.id}.pdf" />
        </div>
      `;
    }
    // 13. Images to PDF
    else if (h === 'img_to_pdf') {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="imgPageSizeSelect">PDF Page Size</label>
          <select id="imgPageSizeSelect" class="form-select">
            <option value="A4" selected>A4 Portrait</option>
            <option value="LETTER">US Letter</option>
            <option value="FIT">Fit Exact Photo Dimensions</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="imgMarginInput">Margin (pt)</label>
          <input id="imgMarginInput" class="form-input" type="number" min="0" max="100" value="20" />
        </div>
        <div class="form-group">
          <label class="form-label" for="outputNameInput">Output Filename</label>
          <input id="outputNameInput" class="form-input" type="text" value="oneclick-photos.pdf" />
        </div>
      `;
    }
    // 14. Image Studio Tools (Compress, Resize, Convert, Filters, Flip, Watermark, Border, Base64)
    else if (h === 'img_transform' || h === 'img_to_base64') {
      const p = tool.preset || {};
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="imgOutFormatSelect">Output Image Format</label>
          <select id="imgOutFormatSelect" class="form-select">
            <option value="image/jpeg" ${p.format === 'image/jpeg' ? 'selected' : ''}>JPEG (.jpg)</option>
            <option value="image/png" ${p.format === 'image/png' ? 'selected' : ''}>PNG (.png)</option>
            <option value="image/webp" ${p.format === 'image/webp' ? 'selected' : ''}>WebP (.webp)</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="imgQualityInput">Compression Quality (0.10 – 1.00)</label>
          <input id="imgQualityInput" class="form-input" type="number" step="0.05" min="0.1" max="1.0" value="${p.quality || 0.85}" />
        </div>
        <div class="form-group">
          <label class="form-label" for="imgScaleInput">Resize Scale Multiplier (e.g. 0.5 = 50%)</label>
          <input id="imgScaleInput" class="form-input" type="number" step="0.05" min="0.1" max="3.0" value="${p.scale || 1.0}" />
        </div>
        <div class="form-group">
          <label class="form-label" for="imgFilterSelect">Visual Filter</label>
          <select id="imgFilterSelect" class="form-select">
            <option value="none">Original Colors</option>
            <option value="grayscale" ${p.filter === 'grayscale' ? 'selected' : ''}>Black &amp; White Grayscale</option>
            <option value="sepia" ${p.filter === 'sepia' ? 'selected' : ''}>Vintage Sepia</option>
            <option value="invert" ${p.filter === 'invert' ? 'selected' : ''}>Invert Negative</option>
            <option value="brightness" ${p.filter === 'brightness' ? 'selected' : ''}>Brighten Exposure</option>
            <option value="contrast" ${p.filter === 'contrast' ? 'selected' : ''}>High Contrast</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="imgWatermarkText">Optional Photo Watermark Text</label>
          <input id="imgWatermarkText" class="form-input" type="text" value="${p.watermarkText || ''}" placeholder="Leave empty for none" />
        </div>
      `;
    }
    // 15. Age & Birthday Calculator
    else if (h === 'calc_age') {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="dobInput">Select Date of Birth</label>
          <input id="dobInput" class="form-input" type="date" value="2000-01-01" />
        </div>
      `;
    }
    // 16. Shamsi / Hijri / Gregorian Calendar Converter
    else if (h === 'calc_calendar' || h === 'calc_datediff') {
      const todayIso = new Date().toISOString().slice(0, 10);
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="calDate1Input">Start / Target Date</label>
          <input id="calDate1Input" class="form-input" type="date" value="${todayIso}" />
        </div>
        ${
          h === 'calc_datediff'
            ? `<div class="form-group">
                <label class="form-label" for="calDate2Input">End Date</label>
                <input id="calDate2Input" class="form-input" type="date" value="2027-01-01" />
              </div>`
            : ''
        }
      `;
    }
    // 17. Interactive Typing Speed Test (WPM)
    else if (h === 'typing_speed') {
      const samplePassage =
        'OneClick is a fast, private, all-in-one digital toolkit that runs inside your browser. Practice your typing speed every day to build accuracy, confidence, and professional productivity.';
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label">Target Passage to Type</label>
          <div id="typingTargetBox" style="padding:0.75rem;border-radius:8px;background:var(--bg-elevated);font-size:0.84rem;line-height:1.5;user-select:none;">${samplePassage}</div>
        </div>
        <div class="form-group">
          <label class="form-label" for="typingUserInput">Start Typing Below (Timer starts automatically)</label>
          <textarea id="typingUserInput" class="form-textarea" placeholder="Start typing the passage above..."></textarea>
        </div>
      `;
      this._bindLiveTypingTest(samplePassage);
    }
    // 18. Financial, Health & Unit Calculators
    else if (h.startsWith('calc_')) {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="calcVal1">Primary Value (Amount / Weight kg / Value)</label>
          <input id="calcVal1" class="form-input" type="number" step="any" value="70" />
        </div>
        <div class="form-group">
          <label class="form-label" for="calcVal2">Secondary Value (Height cm / Rate % / Persons)</label>
          <input id="calcVal2" class="form-input" type="number" step="any" value="175" />
        </div>
        <div class="form-group">
          <label class="form-label" for="calcVal3">Tertiary Value (Months / Years / Tax %)</label>
          <input id="calcVal3" class="form-input" type="number" step="any" value="12" />
        </div>
      `;
    }
    // 19. Text, QR, Hash & Developer Utilities
    else {
      this.configContainer.innerHTML = `
        <div class="form-group">
          <label class="form-label" for="utilTextInput">Input Text / Payload / Length</label>
          <textarea id="utilTextInput" class="form-textarea">OneClick Global Toolkit — Fast, Free & Private!\nhttps://oneclick.app\ncontact@oneclick.app</textarea>
        </div>
      `;
    }
  }

  _bindLiveTypingTest(targetPassage) {
    this.typingStartTime = null;
    const input = document.getElementById('typingUserInput');
    if (!input) return;

    input.addEventListener('input', () => {
      if (!this.typingStartTime) {
        this.typingStartTime = performance.now();
      }
      const typed = input.value;
      const elapsedMinutes = Math.max(0.01, (performance.now() - this.typingStartTime) / 60000);
      const wordCount = typed.trim() ? typed.trim().split(/\s+/).length : 0;
      const wpm = Math.round(wordCount / elapsedMinutes);

      let correctChars = 0;
      for (let i = 0; i < typed.length; i++) {
        if (typed[i] === targetPassage[i]) correctChars++;
      }
      const accuracy = typed.length ? Math.round((correctChars / typed.length) * 100) : 100;

      this.resultMetaText.innerHTML = `<span>Speed: <strong>${wpm} WPM</strong></span><span>Accuracy: <strong>${accuracy}%</strong></span>`;
      this.resultCard.classList.add('visible');
    });
  }

  _initSignaturePad() {
    const canvas = document.getElementById('signatureCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.strokeStyle = '#064e3b';
    ctx.lineWidth = 2.6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    ctx.font = 'italic bold 26px Georgia, serif';
    ctx.fillStyle = '#064e3b';
    ctx.fillText('OneClick Sign', 65, 70);

    let drawing = false;
    const getPos = (e) => {
      const rect = canvas.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      return {
        x: ((clientX - rect.left) / rect.width) * canvas.width,
        y: ((clientY - rect.top) / rect.height) * canvas.height
      };
    };

    const start = (e) => {
      e.preventDefault();
      drawing = true;
      const { x, y } = getPos(e);
      ctx.beginPath();
      ctx.moveTo(x, y);
    };
    const move = (e) => {
      if (!drawing) return;
      e.preventDefault();
      const { x, y } = getPos(e);
      ctx.lineTo(x, y);
      ctx.stroke();
    };
    const end = () => {
      drawing = false;
    };

    canvas.addEventListener('mousedown', start);
    canvas.addEventListener('mousemove', move);
    window.addEventListener('mouseup', end);
    canvas.addEventListener('touchstart', start, { passive: false });
    canvas.addEventListener('touchmove', move, { passive: false });
    window.addEventListener('touchend', end);

    document.getElementById('clearSigBtn')?.addEventListener('click', () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    });
  }

  _setProgress(percent, statusText) {
    this.progressBox.classList.add('visible');
    this.progressFill.style.width = `${percent}%`;
    this.progressPercent.textContent = `${percent}%`;
    this.progressStatus.textContent = statusText;
  }

  _hideProgress() {
    setTimeout(() => {
      this.progressBox.classList.remove('visible');
    }, 300);
  }

  async executeCurrentTool() {
    const tool = ONECLICK_TOOLS.find((t) => t.id === this.activeTool) || ONECLICK_TOOLS[0];
    const h = tool.handler;

    try {
      this.processBtn.disabled = true;
      this.resultCard.classList.remove('visible');
      this.resultExtraContainer.innerHTML = '';

      const outNameEl = document.getElementById('outputNameInput');
      this.lastOutputName = (outNameEl?.value || `oneclick-${tool.id}.pdf`).trim();
      this.lastOutputMime = 'application/pdf';

      // =====================================================================
      // A. STANDALONE CALCULATORS, DATE, TYPING, TEXT, QR & HASH HANDLERS
      // =====================================================================
      if (h === 'calc_age') {
        const dob = document.getElementById('dobInput')?.value || '2000-01-01';
        const res = this.utilEngine.calculateAgeAndBirthday(dob);
        const summary = `Exact Age: ${res.years} Years, ${res.months} Months, ${res.days} Days\nNext Birthday In: ${res.daysUntilNextBirthday} Days (Born on ${res.dayOfWeekBorn})\nTotal Lived: ${res.totalDays.toLocaleString()} Days | ${res.totalWeeks.toLocaleString()} Weeks | ${res.totalHours.toLocaleString()} Hours`;
        this._presentTextResult(summary, 'oneclick-age-report.txt');
        return;
      }

      if (h === 'calc_calendar') {
        const d1 = document.getElementById('calDate1Input')?.value;
        const res = this.utilEngine.convertCalendars(d1);
        const summary = `Gregorian (Miladi): ${res.gregorian}\nIslamic (Hijri): ${res.islamic}\nSolar Hijri (Shamsi / Afghan-Persian): ${res.persian}\nISO Format: ${res.iso}`;
        this._presentTextResult(summary, 'oneclick-calendar-date.txt');
        return;
      }

      if (h === 'calc_datediff') {
        const d1 = new Date(document.getElementById('calDate1Input')?.value || Date.now());
        const d2 = new Date(document.getElementById('calDate2Input')?.value || Date.now());
        const diffDays = Math.round(Math.abs(d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
        const summary = `Days Between Dates: ${diffDays} Days\nWeeks: ${(diffDays / 7).toFixed(1)} Weeks\nApproximate Working Days: ${Math.round((diffDays * 5) / 7)} Days`;
        this._presentTextResult(summary, 'oneclick-date-diff.txt');
        return;
      }

      if (h === 'typing_speed') {
        const typed = document.getElementById('typingUserInput')?.value || '';
        const words = typed.trim() ? typed.trim().split(/\s+/).length : 0;
        const mins = this.typingStartTime ? Math.max(0.05, (performance.now() - this.typingStartTime) / 60000) : 0.5;
        const wpm = Math.round(words / mins);
        this._presentTextResult(`Typing Speed Result: ${wpm} Words Per Minute (WPM)\nTotal Words Typed: ${words}`, 'oneclick-typing-certificate.txt');
        return;
      }

      if (h.startsWith('calc_')) {
        const v1 = Number(document.getElementById('calcVal1')?.value || 0);
        const v2 = Number(document.getElementById('calcVal2')?.value || 1);
        const v3 = Number(document.getElementById('calcVal3')?.value || 1);
        const summary = this._runNumericCalculator(h, v1, v2, v3);
        this._presentTextResult(summary, `oneclick-${tool.id}.txt`);
        return;
      }

      if (h === 'text_util') {
        const raw = document.getElementById('utilTextInput')?.value || '';
        const transformed = this.utilEngine.transformText(raw, tool.mode);
        this._presentTextResult(transformed, `oneclick-${tool.id}.txt`);
        return;
      }

      if (h === 'crypto_hash') {
        const raw = document.getElementById('utilTextInput')?.value || '';
        const sha256 = await this.utilEngine.computeCryptoHash(raw, 'SHA-256');
        const sha512 = await this.utilEngine.computeCryptoHash(raw, 'SHA-512');
        this._presentTextResult(`SHA-256:\n${sha256}\n\nSHA-512:\n${sha512}`, 'oneclick-hashes.txt');
        return;
      }

      if (h === 'qr_generator') {
        const raw = document.getElementById('utilTextInput')?.value || 'https://oneclick.app';
        const dataUrl = this.utilEngine.generateVisualBadgeCanvas(raw, 'OneClick Verified Matrix');
        const res = await fetch(dataUrl);
        const blob = await res.blob();
        this.lastOutputData = blob;
        this.lastOutputName = 'oneclick-matrix-code.png';
        this.lastOutputMime = 'image/png';

        this.resultExtraContainer.innerHTML = `<div style="text-align:center;"><img src="${dataUrl}" alt="Matrix Code" style="max-width:200px;border-radius:8px;border:1px solid var(--border-color);" /></div>`;
        this.resultMetaText.innerHTML = `<span>oneclick-matrix-code.png</span><span>PNG Badge</span>`;
        this.downloadResultBtn.textContent = '⬇ Download Matrix PNG';
        this.resultCard.classList.add('visible');
        return;
      }

      if (h === 'lorem_generator') {
        const lorem =
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n\nDuis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';
        this._presentTextResult(lorem, 'oneclick-lorem-ipsum.txt');
        return;
      }

      if (h === 'text_to_pdf' || h === 'invoice_to_pdf') {
        const title = document.getElementById('txtTitleInput')?.value || '';
        const body = document.getElementById('txtBodyInput')?.value || '';
        const bytes = await this.pdfEngine.createPdfFromText({ title, body, fontSize: 12 }, (p, s) =>
          this._setProgress(p, s)
        );
        this._presentBinaryResult(bytes, this.lastOutputName);
        return;
      }

      // =====================================================================
      // B. IMAGE STUDIO PROCESSING (Requires Image or generates sample canvas)
      // =====================================================================
      const pdfItems = this.items.filter((i) => i.type === 'pdf');
      const imgItems = this.items.filter((i) => i.type === 'image');

      if (h === 'img_transform' || h === 'img_to_base64') {
        if (imgItems.length === 0) {
          throw new Error('Please drop or select at least one Image file (JPG, PNG, WebP) in the upload box first.');
        }
        const format = document.getElementById('imgOutFormatSelect')?.value || tool.preset?.format || 'image/jpeg';
        const quality = Number(document.getElementById('imgQualityInput')?.value || tool.preset?.quality || 0.85);
        const scale = Number(document.getElementById('imgScaleInput')?.value || tool.preset?.scale || 1.0);
        const filter = document.getElementById('imgFilterSelect')?.value || tool.preset?.filter || 'none';
        const watermarkText = document.getElementById('imgWatermarkText')?.value || tool.preset?.watermarkText || '';

        const out = await this.utilEngine.processImage(imgItems[0].file, {
          ...tool.preset,
          format,
          quality,
          scale,
          filter,
          watermarkText
        });

        if (h === 'img_to_base64') {
          this._presentTextResult(out.dataUrl, 'oneclick-image-base64.txt');
          return;
        }

        this.lastOutputData = out.blob;
        this.lastOutputName = `oneclick-image.${out.ext}`;
        this.lastOutputMime = format;
        const sizeKb = (out.blob.size / 1024).toFixed(1);

        this.resultExtraContainer.innerHTML = `<div style="text-align:center;"><img src="${out.dataUrl}" alt="Processed" style="max-width:100%;max-height:160px;border-radius:8px;border:1px solid var(--border-color);" /></div>`;
        this.resultMetaText.innerHTML = `<span>${this.lastOutputName} (${out.width}×${out.height})</span><span>${sizeKb} KB</span>`;
        this.downloadResultBtn.textContent = `⬇ Download ${out.ext.toUpperCase()} Image`;
        this.resultCard.classList.add('visible');
        return;
      }

      if (h === 'img_to_pdf' || (pdfItems.length === 0 && imgItems.length > 0)) {
        if (imgItems.length === 0) {
          throw new Error('Please upload at least one Image (JPG, PNG, WebP) to convert to PDF.');
        }
        const pageSize = document.getElementById('imgPageSizeSelect')?.value || 'A4';
        const margin = Number(document.getElementById('imgMarginInput')?.value ?? 20);
        const bytes = await this.pdfEngine.imagesToPdf(imgItems, { pageSize, margin }, (p, s) =>
          this._setProgress(p, s)
        );
        this._presentBinaryResult(bytes, this.lastOutputName);
        return;
      }

      // =====================================================================
      // C. PDF SUITE PROCESSING
      // =====================================================================
      if (pdfItems.length === 0) {
        await this.loadSampleDocument();
      }
      const activePdfItems = this.items.filter((i) => i.type === 'pdf');

      if (h === 'pdf_to_jpg' || h === 'pdf_to_png' || h === 'pdf_to_webp') {
        const format = h === 'pdf_to_png' ? 'image/png' : h === 'pdf_to_webp' ? 'image/webp' : 'image/jpeg';
        const scale = Number(document.getElementById('exportDpiSelect')?.value || 2.0);
        const images = await this.pdfEngine.pdfToImages(activePdfItems, { format, scale }, (p, s) =>
          this._setProgress(p, s)
        );

        this.lastOutputData = images[0].blob;
        this.lastOutputName = images[0].fileName;
        this.lastOutputMime = format;

        const gallery = document.createElement('div');
        gallery.className = 'result-gallery';
        images.forEach((imgObj) => {
          const link = document.createElement('a');
          link.className = 'result-gallery-item';
          link.href = imgObj.url;
          link.download = imgObj.fileName;
          link.innerHTML = `<img src="${imgObj.url}" alt="${imgObj.fileName}" /><span>⬇ ${imgObj.fileName}</span>`;
          gallery.appendChild(link);
        });

        this.resultMetaText.innerHTML = `<span>${images.length} Page(s) Exported</span><span>Click any page</span>`;
        this.resultExtraContainer.appendChild(gallery);
        this.downloadResultBtn.textContent = `⬇ Download ${images[0].fileName}`;
        this.resultCard.classList.add('visible');
        return;
      }

      if (h === 'pdf_extract_text') {
        const extractedText = await this.pdfEngine.extractTextFromPdf(activePdfItems, (p, s) =>
          this._setProgress(p, s)
        );
        this._presentTextResult(extractedText, 'oneclick-extracted.txt');
        return;
      }

      let outputBytes;
      if (h === 'pdf_split' || h === 'pdf_remove') {
        const rangeStr = document.getElementById('splitRangeInput')?.value || '1';
        const mode = h === 'pdf_remove' ? 'remove' : 'keep';
        outputBytes = await this.pdfEngine.filterByRange(activePdfItems, rangeStr, mode, (p, s) =>
          this._setProgress(p, s)
        );
      } else if (h === 'pdf_reverse') {
        outputBytes = await this.pdfEngine.mergeAndReorderPages([...activePdfItems].reverse(), (p, s) =>
          this._setProgress(p, s)
        );
      } else if (h === 'pdf_compress') {
        const preset = document.getElementById('compressPresetSelect')?.value || 'recommended';
        const PRESETS = {
          extreme: { quality: 0.5, scale: 1.0, colorFilter: 'none' },
          recommended: { quality: 0.68, scale: 1.25, colorFilter: 'none' },
          high: { quality: 0.85, scale: 1.5, colorFilter: 'none' }
        };
        outputBytes = await this.pdfEngine.rasterTransformPdf(activePdfItems, PRESETS[preset], (p, s) =>
          this._setProgress(p, s)
        );
      } else if (h === 'pdf_grayscale' || h === 'pdf_invert' || h === 'pdf_contrast') {
        const colorFilter = document.getElementById('colorFilterSelect')?.value || 'grayscale';
        outputBytes = await this.pdfEngine.rasterTransformPdf(
          activePdfItems,
          { quality: 0.8, scale: 1.35, colorFilter },
          (p, s) => this._setProgress(p, s)
        );
      } else if (h === 'pdf_twoup') {
        outputBytes = await this.pdfEngine.createTwoUpLayout(activePdfItems, (p, s) => this._setProgress(p, s));
      } else if (h === 'pdf_sign') {
        const sigCanvas = document.getElementById('signatureCanvas');
        const sigDataUrl = sigCanvas.toDataURL('image/png');
        const position = document.getElementById('sigPosSelect')?.value || 'bottom-right';
        const targetPages = document.getElementById('sigTargetSelect')?.value || 'last';
        const signerName = document.getElementById('sigSignerInput')?.value || '';
        outputBytes = await this.pdfEngine.signPdfWithPng(
          activePdfItems,
          sigDataUrl,
          { position, targetPages, signerName },
          (p, s) => this._setProgress(p, s)
        );
      } else if (h === 'pdf_pagenums') {
        const format = document.getElementById('pnFormatInput')?.value || 'Page {n} of {total}';
        const headerText = document.getElementById('pnHeaderInput')?.value || '';
        const position = document.getElementById('pnPosSelect')?.value || 'bottom-center';
        outputBytes = await this.pdfEngine.addPageNumbersAndHeaderFooter(
          activePdfItems,
          { format, headerText, position, fontSize: 10 },
          (p, s) => this._setProgress(p, s)
        );
      } else if (h === 'pdf_crop' || h === 'pdf_resize') {
        const mode = document.getElementById('cropModeSelect')?.value || 'crop';
        const targetSize = document.getElementById('cropSizeSelect')?.value || 'A4';
        const marginPt = Number(document.getElementById('cropMarginInput')?.value || 28);
        outputBytes = await this.pdfEngine.cropOrResizePages(
          activePdfItems,
          { mode, targetSize, marginPt },
          (p, s) => this._setProgress(p, s)
        );
      } else if (h === 'pdf_blank') {
        const pos = document.getElementById('blankPosSelect')?.value || 'end';
        const count = Number(document.getElementById('blankCountInput')?.value || 1);
        outputBytes = await this.pdfEngine.insertBlankPages(activePdfItems, pos, count, (p, s) =>
          this._setProgress(p, s)
        );
      } else if (h === 'pdf_watermark') {
        const text = document.getElementById('wmTextInput')?.value || 'CONFIDENTIAL';
        const placement = document.getElementById('wmPlacementSelect')?.value || 'diagonal';
        const opacity = Number(document.getElementById('wmOpacityInput')?.value || 0.28);
        outputBytes = await this.pdfEngine.applyWatermarkAndProtect(
          activePdfItems,
          { text, placement, opacity, fontSize: 44, colorHex: '#d97706', author: 'OneClick Suite' },
          (p, s) => this._setProgress(p, s)
        );
      } else if (h === 'pdf_redact') {
        const label = document.getElementById('metaTitleInput')?.value || 'REDACTED';
        outputBytes = await this.pdfEngine.applyRedactionBox(
          activePdfItems,
          { xPercent: 8, yPercent: 60, widthPercent: 84, heightPercent: 12, label },
          (p, s) => this._setProgress(p, s)
        );
      } else if (h === 'pdf_scrub_meta' || h === 'pdf_edit_meta') {
        const title = document.getElementById('metaTitleInput')?.value || '';
        const author = document.getElementById('metaAuthorInput')?.value || '';
        outputBytes = await this.pdfEngine.updateOrScrubMetadata(
          activePdfItems,
          { scrubAll: h === 'pdf_scrub_meta', title, author, subject: 'OneClick Suite', keywords: '' },
          (p, s) => this._setProgress(p, s)
        );
      } else {
        outputBytes = await this.pdfEngine.mergeAndReorderPages(activePdfItems, (p, s) =>
          this._setProgress(p, s)
        );
      }

      this._presentBinaryResult(outputBytes, this.lastOutputName);
    } catch (err) {
      alert(`OneClick Tool Notice: ${err.message}`);
    } finally {
      this.processBtn.disabled = false;
      this._hideProgress();
    }
  }

  _runNumericCalculator(handler, v1, v2, v3) {
    if (handler === 'calc_bmi') {
      const hMeters = v2 / 100;
      const bmi = v1 / (hMeters * hMeters);
      const cat = bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal Weight' : bmi < 30 ? 'Overweight' : 'Obese';
      return `BMI Score: ${bmi.toFixed(1)}\nCategory: ${cat}\nInput: ${v1} kg, ${v2} cm`;
    }
    if (handler === 'calc_emi') {
      const r = v2 / 12 / 100;
      const n = v3;
      const emi = r === 0 ? v1 / n : (v1 * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      const total = emi * n;
      return `Monthly EMI: ${emi.toFixed(2)}\nTotal Payable: ${total.toFixed(2)}\nTotal Interest: ${(total - v1).toFixed(2)}`;
    }
    if (handler === 'calc_pct') {
      return `${v2}% of ${v1} = ${((v1 * v2) / 100).toFixed(2)}\n${v1} increased by ${v2}% = ${(v1 * (1 + v2 / 100)).toFixed(2)}`;
    }
    if (handler === 'calc_discount') {
      const saved = (v1 * v2) / 100;
      const afterDisc = v1 - saved;
      const tax = (afterDisc * v3) / 100;
      return `Final Price: ${(afterDisc + tax).toFixed(2)}\nYou Save: ${saved.toFixed(2)}\nTax Added (${v3}%): ${tax.toFixed(2)}`;
    }
    if (handler === 'calc_tip') {
      const tip = (v1 * v2) / 100;
      const total = v1 + tip;
      const perPerson = total / Math.max(1, v3);
      return `Total with Tip: ${total.toFixed(2)}\nPer Person (${v3} people): ${perPerson.toFixed(2)}`;
    }
    if (handler === 'calc_unit_length') {
      return `${v1} Meters = ${(v1 / 1000).toFixed(4)} km | ${(v1 * 3.28084).toFixed(2)} ft | ${(v1 * 39.3701).toFixed(2)} in | ${(v1 * 0.000621371).toFixed(4)} miles`;
    }
    if (handler === 'calc_unit_weight') {
      return `${v1} kg = ${(v1 * 1000).toFixed(0)} g | ${(v1 * 2.20462).toFixed(2)} lbs | ${(v1 * 35.274).toFixed(2)} oz`;
    }
    if (handler === 'calc_unit_temp') {
      return `${v1} °C = ${((v1 * 9) / 5 + 32).toFixed(2)} °F | ${(v1 + 273.15).toFixed(2)} K`;
    }
    if (handler === 'calc_unit_data') {
      return `${v1} MB = ${(v1 * 1024).toFixed(0)} KB | ${(v1 / 1024).toFixed(4)} GB | ${(v1 * 8).toFixed(0)} Mbit`;
    }
    if (handler === 'calc_roman') {
      let num = Math.min(3999, Math.max(1, Math.floor(v1)));
      const lookup = [
        ['M', 1000], ['CM', 900], ['D', 500], ['CD', 400],
        ['C', 100], ['XC', 90], ['L', 50], ['XL', 40],
        ['X', 10], ['IX', 9], ['V', 5], ['IV', 4], ['I', 1]
      ];
      let roman = '';
      for (const [sym, val] of lookup) {
        while (num >= val) {
          roman += sym;
          num -= val;
        }
      }
      return `Roman Numeral: ${roman}`;
    }
    return `Result: ${(v1 + v2).toFixed(2)}`;
  }

  _presentTextResult(textContent, filename) {
    this.lastOutputData = textContent;
    this.lastOutputName = filename;
    this.lastOutputMime = 'text/plain;charset=utf-8';

    const previewArea = document.createElement('textarea');
    previewArea.className = 'form-textarea';
    previewArea.readOnly = true;
    previewArea.value = textContent;
    this.resultExtraContainer.appendChild(previewArea);

    const sizeKb = (new Blob([textContent]).size / 1024).toFixed(2);
    this.resultMetaText.innerHTML = `<span>${filename}</span><span>${sizeKb} KB</span>`;
    this.downloadResultBtn.textContent = `⬇ Download ${filename}`;
    this.resultCard.classList.add('visible');
  }

  _presentBinaryResult(bytes, filename) {
    if (!filename.toLowerCase().endsWith('.pdf')) {
      filename += '.pdf';
    }
    this.lastOutputData = bytes;
    this.lastOutputName = filename;
    this.lastOutputMime = 'application/pdf';

    const sizeKb = (bytes.byteLength / 1024).toFixed(1);
    this.resultMetaText.innerHTML = `<span>${filename}</span><span>${sizeKb} KB</span>`;
    this.downloadResultBtn.textContent = '⬇ Download Processed PDF';
    this.resultCard.classList.add('visible');
  }
}

window.addEventListener('DOMContentLoaded', () => {
  window.oneClickApp = new OneClickApp();
});
