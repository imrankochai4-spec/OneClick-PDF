// File: android/app/src/main/java/com/emerald/pdftoolkit/MainActivity.kt
package com.emerald.pdftoolkit

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import com.getcapacitor.BridgeActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : BridgeActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        configureOfflineWebViewCache()
        registerHardwareBackHandler()
    }

    /**
     * Configures the Capacitor WebView for high-performance client-side PDF canvas
     * processing, native Blob/Base64 file downloads, and offline-first caching.
     */
    private fun configureOfflineWebViewCache() {
        val webView: WebView = bridge?.webView ?: return
        val settings: WebSettings = webView.settings

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.textZoom = 100
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.mediaPlaybackRequiresUserGesture = false

        // Register native JS bridge for instant client-side Blob/Base64 downloads on Android
        webView.addJavascriptInterface(AndroidDownloadBridge(this), "AndroidDownloader")

        // Handle standard HTTP/HTTPS and Data URL downloads inside Android WebView
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                if (url.startsWith("data:")) {
                    val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                    val base64Part = url.substringAfter("base64,", "")
                    if (base64Part.isNotEmpty()) {
                        AndroidDownloadBridge(this).saveBase64File(base64Part, fileName, mimeType ?: "application/octet-stream")
                    }
                } else if (url.startsWith("http://") || url.startsWith("https://")) {
                    val request = DownloadManager.Request(Uri.parse(url)).apply {
                        setMimeType(mimeType)
                        addRequestHeader("User-Agent", userAgent)
                        setDescription("Downloading file from OneClick...")
                        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                        setTitle(fileName)
                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                    }
                    val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    dm.enqueue(request)
                    Toast.makeText(applicationContext, "Downloading to Downloads folder...", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(applicationContext, "Download error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Native bridge allowing client-side JS (pdf-lib, Canvas, Blob) to save files
     * directly into the Android Downloads folder without any server.
     */
    class AndroidDownloadBridge(private val context: Context) {
        @JavascriptInterface
        fun saveBase64File(base64Data: String, fileName: String, mimeType: String): Boolean {
            return try {
                val cleanBase64 = if (base64Data.contains(",")) base64Data.substringAfter(",") else base64Data
                val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
                val safeName = fileName.ifBlank { "oneclick-output.pdf" }
                val safeMime = mimeType.ifBlank { "application/octet-stream" }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val resolver = context.contentResolver
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, safeMime)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        ?: throw IllegalStateException("Could not create file in Downloads")

                    resolver.openOutputStream(uri)?.use { out ->
                        out.write(bytes)
                        out.flush()
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                } else {
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!downloadsDir.exists()) downloadsDir.mkdirs()
                    val outFile = File(downloadsDir, safeName)
                    FileOutputStream(outFile).use { out ->
                        out.write(bytes)
                        out.flush()
                    }
                }

                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(
                        context.applicationContext,
                        "✅ Saved to Downloads: $safeName",
                        Toast.LENGTH_LONG
                    ).show()
                }
                true
            } catch (e: Exception) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.makeText(
                        context.applicationContext,
                        "⚠️ Could not save file: ${e.localizedMessage}",
                        Toast.LENGTH_LONG
                    ).show()
                }
                false
            }
        }
    }

    /**
     * Android 14+ (API 34) predictive back gesture & hardware back-button support.
     * Navigates WebView history or delegates workspace reset before exiting the app.
     */
    private fun registerHardwareBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val webView = bridge?.webView
                if (webView != null && webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) {
            bridge?.webView?.clearCache(false)
        }
    }
}
