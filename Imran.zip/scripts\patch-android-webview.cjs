// File: scripts/patch-android-webview.cjs
const fs = require('fs');
const path = require('path');

const mainActivityJavaPath = path.join(
  __dirname,
  '..',
  'android',
  'app',
  'src',
  'main',
  'java',
  'com',
  'oneclick',
  'suite',
  'MainActivity.java'
);

const javaSource = `package com.oneclick.suite;

import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import com.getcapacitor.BridgeActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureDownloadSupport();
    }

    private void configureDownloadSupport() {
        if (this.bridge == null || this.bridge.getWebView() == null) return;
        WebView webView = this.bridge.getWebView();
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setTextZoom(100);

        final AndroidDownloadBridge downloadBridge = new AndroidDownloadBridge(this);
        webView.addJavascriptInterface(downloadBridge, "AndroidDownloader");

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                if (url != null && url.startsWith("data:")) {
                    String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                    int idx = url.indexOf("base64,");
                    if (idx != -1) {
                        String b64 = url.substring(idx + 7);
                        downloadBridge.saveBase64File(b64, fileName, mimeType != null ? mimeType : "application/octet-stream");
                    }
                } else if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                    DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                    req.setMimeType(mimeType);
                    req.addRequestHeader("User-Agent", userAgent);
                    req.setTitle(fileName);
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (dm != null) dm.enqueue(req);
                    Toast.makeText(getApplicationContext(), "Downloading " + fileName + "...", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Download error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public static class AndroidDownloadBridge {
        private final Context context;

        public AndroidDownloadBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public boolean saveBase64File(String base64Data, String fileName, String mimeType) {
            try {
                String clean = base64Data.contains(",") ? base64Data.substring(base64Data.indexOf(",") + 1) : base64Data;
                byte[] bytes = Base64.decode(clean, Base64.DEFAULT);
                final String safeName = (fileName == null || fileName.trim().isEmpty()) ? "oneclick-output.pdf" : fileName.trim();
                String safeMime = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType.trim();

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, safeMime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    values.put(MediaStore.Downloads.IS_PENDING, 1);

                    Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IllegalStateException("Cannot create file in Downloads");
                    try (OutputStream out = context.getContentResolver().openOutputStream(uri)) {
                        if (out != null) {
                            out.write(bytes);
                            out.flush();
                        }
                    }
                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    context.getContentResolver().update(uri, values, null, null);
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    File outFile = new File(dir, safeName);
                    try (FileOutputStream out = new FileOutputStream(outFile)) {
                        out.write(bytes);
                        out.flush();
                    }
                }

                new Handler(Looper.getMainLooper()).post(() ->
                    Toast.makeText(context.getApplicationContext(), "Saved to Downloads: " + safeName, Toast.LENGTH_LONG).show()
                );
                return true;
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() ->
                    Toast.makeText(context.getApplicationContext(), "Save error: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
                return false;
            }
        }
    }
}
`;

fs.mkdirSync(path.dirname(mainActivityJavaPath), { recursive: true });
fs.writeFileSync(mainActivityJavaPath, javaSource, 'utf8');
console.log('Patched Android MainActivity.java with native download support.');
